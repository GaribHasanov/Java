 private void passwordKeyReleased(java.awt.event.KeyEvent evt) {                                     
        // TODO add your handling code here:
        label_password.setText("");
    }                                    
