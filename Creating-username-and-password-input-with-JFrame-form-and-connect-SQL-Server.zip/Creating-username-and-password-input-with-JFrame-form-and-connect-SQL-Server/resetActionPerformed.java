private void resetActionPerformed(java.awt.event.ActionEvent evt) {                                      
        // TODO add your handling code here:
        username.setText("");
        password.setText("");

    }                                     
