private void usernameKeyReleased(java.awt.event.KeyEvent evt) {                                     
        // TODO add your handling code here:
        label_username.setText("");
    }                                    
