 try {
            
           Properties prop =  new Properties();
           FileReader reader = new FileReader("C:\\Users\\Garibhasanov\\Documents\\NetBeansProjects\\smsapp\\src\\smsapp\\db.properties");
           FileReader reader2 = new FileReader("C:\\Users\\Garibhasanov\\Desktop\\smsapp\\db.properties");

           prop.load(reader);
            
           // if (txtmess.getText().length() >= 3 ) {
     int yesorno2 =     JOptionPane.showConfirmDialog(null,"Göndərilsin?","",JOptionPane.YES_NO_OPTION);
      
                        if (yesorno2 == JOptionPane.YES_OPTION){
			// Construct data
			//String apiKey = "apikey=" + "CNtK4tjslew-LcCFTSQCXxCjztkJbePhLUquCpC5iz";
			//String message = "&message=" + "Tesdiq edirsiniz ?";
			//String sender = "&sender=" + "Garibce";
			//String numbers = "&numbers=" + txtnumber.getText();
                        String account =  "&account=" + "embaapi";
                        String password = "&password=" + "P@sp0rt1";
                        String port = "&port=" + prop.getProperty("port");
			String destination = "&destination=" + txtnumb.getText();
                        String content = "&content=" + txtmess.getText();
                        String api = prop.getProperty("url");
                        			// Send data
			HttpURLConnection conn = (HttpURLConnection) new URL(api).openConnection();
			String data = content + destination + account + password + port;
                        
                        //if (txtmess.getText().length() >= 3 )
               
                        //JOptionPane.showConfirmDialog(null,"Göndərilsin?","Simvol sayı çoxdur",JOptionPane.YES_NO_OPTION);
                         
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Length", Integer.toString(data.length()));
			conn.getOutputStream().write(data.getBytes("UTF-8"));
			final BufferedReader rd = new BufferedReader(new InputStreamReader(conn.getInputStream()));
			final StringBuffer stringBuffer = new StringBuffer();
			String line;
			while ((line = rd.readLine()) != null) {
				//stringBuffer.append(line);
                        JOptionPane.showMessageDialog(null, "Mesajınız göndərildi " + line);
			}
			rd.close();
       }
                        if (yesorno2 == JOptionPane.NO_OPTION){
                        System.out.println("roll");
                        }//}
            
			//return stringBuffer.toString();
		} catch (Exception e) {
			//System.out.println("Error SMS "+e);
                        //JOptionPane.showMessageDialog(null, e);
			//return "Error "+e;
		}
    //}
        
    } 